## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----eval = FALSE-------------------------------------------------------------
# library(datazoom.saude)
# 
# # Download raw birth data for 2023 in the state of Rio de Janeiro (RJ).
# data_raw_births <- load_births(
#   time_period = 2023,
#   states = "RJ"
# )
# 
# # Download raw birth data for 2020 in the states of Rio de Janeiro (RJ) and São Paulo (SP),
# # keeping the original raw format.
# data_raw_births2 <- load_births(
#   time_period = 2020,
#   states = c("RJ","SP"),
#   raw_data = TRUE
# )
# 
# # Download raw birth data for 2014 in the state of Amazonas (AM),
# # with variable labels in Portuguese.
# data_raw_births3 <- load_births(
#   time_period = 2014,
#   states = "AM",
#   language = "pt"
# )
# 
# # Download processed birth data for 2015 in the state of Amazonas (AM),
# # with variable labels in Portuguese for easier analysis.
# data_processed_births <- load_births(
#   time_period = 2015,
#   states = "AM",
#   raw_data = FALSE,
#   language = "pt"
# )

