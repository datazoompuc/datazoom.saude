## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----eval = FALSE-------------------------------------------------------------
# library(datazoom.saude)
# 
# # Download processed oncology data for the year 2023.
# # This will return data from the Oncology Panel for all Brazilian states.
# oncology_cases_treated <- load_oncology_case(
#   time_period = 2023,
#   raw_data = FALSE,
#   language = "eng"
# )
# 
# # Download raw oncology data for the years 2021 to 2022 with labels in portuguese.
# oncology_cases_raw <- load_oncology_case(
#   time_period = 2021:2022,
#   raw_data = TRUE,
#   language = "pt"
# )

