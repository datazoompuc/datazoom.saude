## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----eval = FALSE-------------------------------------------------------------
# library(datazoom.saude)
# 
# # Download treated data - States of Amazonas and Pará, 2010.
# data_beds_full <- load_hospital_beds(
#   time_period = 2010,
#   states = c("AM", "PA"),
#   raw_data = FALSE,
#   language = "eng"
# )
# 
# # Download treated data - Brrazil, 2010 to 2022.
# # Descriptions in Portuguese.
# data_beds_full <- load_hospital_beds(
#   time_period = 2010:2022,
#   states = "all",
#   raw_data = FALSE,
#   language = "pt"
# )
# 
# # Download raw data - States of Rio de Janeiro, 2015.
# data_beds_raw <- load_hospital_beds(
#   time_period = 2015,
#   states = "RJ",
#   raw_data = TRUE,
#   language = "eng"
# )

