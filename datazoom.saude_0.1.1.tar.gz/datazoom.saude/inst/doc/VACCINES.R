## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----eval = FALSE-------------------------------------------------------------
# library(datazoom.saude)
# 
# # Download data for Yellow Fever via web scraping (Routine strategy) - State of Acre, 2020
# data_fa_acre <- load_vaccines(
#   year = 2020,
#   state = "AC",
#   strategy = "Rotina",
#   product = "Febre amarela - FA",
#   language = "eng"
# )
# 
# # Download data for BCG via web scraping (Private Service strategy) - State of São Paulo, 2018
# data_bcg_sp <- load_vaccines(
#   year = 2018,
#   state = "SP",
#   strategy = "Serviço Privado",
#   product = "BCG - BCG",
#   language = "pt"
# )
# 
# # Download data for Trivalent Influenza using a manually downloaded file (Blockade strategy) - State of Acre, 2018
# data_fa_acre <- load_vaccines(
#   year = 2018,
#   state = "AC",
#   strategy = "Bloqueio",
#   product = "Influenza Trivalente - FLU3V",
#   doses = c("D1", "DU", "REV", "DI"), # required for data up to 2022
#   data = "C:/path/to/downloaded_file.xls", #.xls
#   language = "eng"
# )
# 
# # Download data for Trivalent Influenza using a manually downloaded file (Blockade strategy) - State of Minas Gerais, 2024
# data_fa_acre <- load_vaccines(
#   year = 2024,
#   state = "MG",
#   strategy = "Bloqueio",
#   product = "Influenza Trivalente - FLU3V",
#   doses = NULL, # not required for data 2023 onwards
#   data = "C:/path/to/downloaded_file.xls", #.xls
#   language = "pt"
# )
# 
# # Example of calling the function to trigger interactive selection - State of Minas Gerais, 2010
# data_interactive <- load_vaccines(
#   year = 2010,
#   state = "MG",
#   language = "pt")

