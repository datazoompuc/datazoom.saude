## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----eval = FALSE-------------------------------------------------------------
# library(datazoom.saude)
# 
# # Download raw data for Reduced AIHs (AIHs Reduzida) – All country, 2010.
# data_rd_raw <- load_hospital_admissions(
#   dataset = "reduced_aih",
#   time_period = 2010,
#   states = "all",
#   raw_data = TRUE,
#   language = "eng"
# )
# 
# # Download processed data for Rejected AIHs with Error Codes – State of Amazonas, 2010 to 2020.
# # Descriptions in Portuguese.
# data_er_processed <- load_hospital_admissions(
#   dataset = "rejected_aih_error",
#   time_period = 2010:2020,
#   states = "AM",
#   raw_data = FALSE,
#   language = "pt"
# )
# 
# # Download raw data for Professional Services – States of Rio and São Paulo, 2022.
# data_sp_raw <- load_hospital_admissions(
#   dataset = "professional_services",
#   time_period = 2022,
#   states = C("RJ","SP"),
#   raw_data = TRUE,
#   language = "eng"
# )
# 
# # Download processed data for Professional Services – Federal District, 2020 to 2022.
# # Descriptions in Portuguese.
# data_sp_processed <- load_hospital_admissions(
#   dataset = "professional_services",
#   time_period = 2020:2022,
#   states = "DF",
#   raw_data = FALSE,
#   language = "pt"
# )

