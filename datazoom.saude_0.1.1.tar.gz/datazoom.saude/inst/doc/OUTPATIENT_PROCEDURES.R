## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----eval = FALSE-------------------------------------------------------------
# library(datazoom.saude)
# 
# # Download processed data for Post-Bariatric Surgery Follow-Up (ABO) – State of Acre, 2012.
# bariatric_surgery_follow_up <- load_outpatient_procedures(
#   dataset = "bariatric_surgery_follow_up",
#   time_period = 2012,
#   states = "AC",
#   raw_data = FALSE,
#   language = "eng"
# )
# 
# # Download processed data for Consolidated Outpatient Procedures (PA) – State of Acre, 2022.
# # Descriptions in Portuguese.
# ambulatory_production <- load_outpatient_procedures(
#   dataset = "ambulatory_production",
#   time_period = 2022,
#   states = "AC",
#   raw_data = FALSE,
#   language = "pt"
# )
# 
# # Download raw data for High-Cost Medications (AM) - State of Pernambuco, 2021.
# medicines_raw <- load_outpatient_procedures(
#   dataset = "medicines",
#   time_period = 2021,
#   states = "PE",
#   raw_data = TRUE,
#   language = "eng"
# )
# 
# # Download processed data for Psychosocial Care (PS) - State of Acre, 2022 to 2023.
# psychosocial <- load_outpatient_procedures(
#   dataset = "psychosocial",
#   time_period = 2022:2023,
#   states = "AC",
#   raw_data = FALSE,
#   language = "eng"
# )

