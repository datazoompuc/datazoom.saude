## ----include = FALSE----------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----eval = FALSE-------------------------------------------------------------
# library(datazoom.saude)
# 
# # Download raw data for general mortality - State of Rio de Janeiro, 2022.
# raw_data_general_rj <- load_mortality(
#   dataset = "general",
#   time_period = 2022,
#   states = "RJ",
#   raw_data = TRUE
# )
# 
# # Download treated data for general mortality - States of Rio and São Paulo, 2022.
# trated_data_general_rj <- load_mortality(
#   dataset = "general",
#   time_period = 2022,
#   states = c("RJ", "SP"),
#   raw_data = FALSE,
#   keep_all = FALSE # Explicitly stating default behavior
# )
# 
# # Download treated data for Maternal Deaths - Brazil, 2020 to 2022.
# # Descriptions in Portuguese.
# # Note: `maternal` does not provide separate files by state.
# data_maternal_pt <- load_mortality(
#   dataset = "maternal",
#   time_period = 2020:2022,
#   states = "all",
#   raw_data = FALSE,
#   language = "pt"
# )
# 
# # Download treated data for Infant Deaths - Brazil, 2017.
# # Keeping all individual variables (not aggregated).
# data_infant_full <- load_mortality(
#   dataset = "infant",
#   time_period = 2017,
#   states = "all",
#   raw_data = FALSE,
#   keep_all = TRUE,
#   language = "eng"
# )
# 
# # Download treated data for Fetal Deaths - State of Amazonas, 2000.
# data_infant_full <- load_mortality(
#   dataset = "fetal",
#   time_period = 2000,
#   states = "AM",
#   raw_data = FALSE,
#   language = "eng"
# )
# 
# # Download treated data for External Causes Deaths - State of Acre, 2022.
# data_infant_full <- load_mortality(
#   dataset = "fetal",
#   time_period = 2022,
#   states = "AC",
#   raw_data = FALSE,
#   language = "eng"
# )

